"""Registration text messages."""
