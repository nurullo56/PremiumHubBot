"""Admin text messages."""
