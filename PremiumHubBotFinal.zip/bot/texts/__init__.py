"""Text messages package."""
