"""Common utilities."""
